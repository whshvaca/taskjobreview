﻿(function(){
	/** State **/
	/** @typedef {{ id:string, date:string, text:string, images:string[] }} WorkItem */
	/** @type {WorkItem[]} */
	let items = [];
	/** @type {Date} */
	let weekAnchor = getMonday(new Date());

	/** Elements **/
	const textInput = document.getElementById('textInput');
	const fileInput = document.getElementById('fileInput');
	const pasteZone = document.getElementById('pasteZone');
	const preview = document.getElementById('preview');
	const dateInput = document.getElementById('dateInput');
	const addBtn = document.getElementById('addBtn');
	const weekGrid = document.getElementById('weekGrid');
	const weekLabel = document.getElementById('weekLabel');
	const prevWeekBtn = document.getElementById('prevWeek');
	const nextWeekBtn = document.getElementById('nextWeek');
	const todayBtn = document.getElementById('todayBtn');

	/** Setup **/
	dateInput.value = toInputDate(new Date());
	load();
	renderWeek();

	/** Image selection & preview **/
	let stagedImages = [];

	fileInput.addEventListener('change', async (e)=>{
		const files = Array.from(e.target.files||[]);
		await addFiles(files);
	});

	// Drag & drop
	;['dragenter','dragover'].forEach(ev=>pasteZone.addEventListener(ev, (e)=>{
		e.preventDefault();
		pasteZone.classList.add('drag');
	}));
	;['dragleave','drop'].forEach(ev=>pasteZone.addEventListener(ev, (e)=>{
		e.preventDefault();
		pasteZone.classList.remove('drag');
	}));
	pasteZone.addEventListener('drop', async (e)=>{
		const files = Array.from(e.dataTransfer?.files||[]).filter(f=>f.type.startsWith('image/'));
		await addFiles(files);
	});

	// Click focus opens file
	pasteZone.addEventListener('click', ()=> fileInput.click());

	// Paste from clipboard anywhere on page
	document.addEventListener('paste', async (e)=>{
		const itemsList = Array.from(e.clipboardData?.items||[]);
		const imageItems = itemsList.filter(it=> it.kind==='file' && it.type.startsWith('image/'));
		if(imageItems.length===0) return;
		const files = await Promise.all(imageItems.map(it=> it.getAsFile()));
		await addFiles(files.filter(Boolean));
	});

	async function addFiles(files){
		for(const f of files){
			const dataUrl = await fileToDataUrl(f);
			stagedImages.push(dataUrl);
		}
		renderPreview();
	}

	function renderPreview(){
		preview.innerHTML='';
		stagedImages.forEach((src,idx)=>{
			const wrap = document.createElement('div');
			wrap.className='thumb';
			const img = document.createElement('img');
			img.src = src;
			const rm = document.createElement('button');
			rm.className='remove';
			rm.textContent='×';
			rm.addEventListener('click', ()=>{
				stagedImages.splice(idx,1);
				renderPreview();
			});
			wrap.appendChild(img);
			wrap.appendChild(rm);
			preview.appendChild(wrap);
		});
	}

	/** Add item **/
	addBtn.addEventListener('click', onAdd);
	textInput.addEventListener('keydown', (e)=>{
		if((e.ctrlKey||e.metaKey) && e.key==='Enter') onAdd();
	});

	function onAdd(){
		const text = (textInput.value||'').trim();
		const dateStr = dateInput.value || toInputDate(new Date());
		if(!text && stagedImages.length===0) return;
		const item = { id: cryptoRandomId(), date: dateStr, text, images: [...stagedImages] };
		items.push(item);
		save();
		// reset
		textInput.value='';
		stagedImages = [];
		renderPreview();
		// re-render
		renderWeek();
	}

	/** Week navigation **/
	prevWeekBtn.addEventListener('click', ()=>{ weekAnchor = addDays(weekAnchor,-7); renderWeek(); });
	nextWeekBtn.addEventListener('click', ()=>{ weekAnchor = addDays(weekAnchor, 7); renderWeek(); });
	todayBtn.addEventListener('click', ()=>{ weekAnchor = getMonday(new Date()); renderWeek(); });

	function renderWeek(){
		const monday = getMonday(weekAnchor);
		const days = Array.from({length:7},(_,i)=> addDays(monday,i));
		const sunday = days[6];
		weekLabel.textContent = `${formatDate(monday)} - ${formatDate(sunday)}`;

		weekGrid.innerHTML='';
		for(const day of days){
			const dayCol = document.createElement('div'); dayCol.className='day-col';
			const head = document.createElement('div'); head.className='day-head';
			const name = day.toLocaleDateString('zh-TW',{ weekday:'short'});
			const dateStr = toInputDate(day);
			head.innerHTML = `<span>${name}</span><span class="date">${dateStr}</span>`;
			dayCol.appendChild(head);

			const dayItems = items
				.filter(it=> it.date===dateStr)
				.sort((a,b)=> a.id.localeCompare(b.id));
			if(dayItems.length===0){
				const empty = document.createElement('div'); empty.className='empty'; empty.textContent='無項目';
				dayCol.appendChild(empty);
			}else{
				for(const it of dayItems){
					const card = document.createElement('div'); card.className='item';
					const text = document.createElement('div'); text.className='text'; text.textContent = it.text;
					card.appendChild(text);
					if(it.images?.length){
						const imgs = document.createElement('div'); imgs.className='images';
						for(const src of it.images){
							const img = document.createElement('img'); img.src = src; img.alt='';
							img.addEventListener('click', ()=> openImage(src));
							imgs.appendChild(img);
						}
						card.appendChild(imgs);
					}
					dayCol.appendChild(card);
				}
			}
			weekGrid.appendChild(dayCol);
		}
	}

	/** Storage **/
	function load(){
		try{
			const raw = localStorage.getItem('worklog.items');
			items = raw ? JSON.parse(raw) : [];
		}catch(e){ items = []; }
	}
	function save(){
		localStorage.setItem('worklog.items', JSON.stringify(items));
	}

	/** Utils **/
	function toInputDate(d){
		const y = d.getFullYear();
		const m = String(d.getMonth()+1).padStart(2,'0');
		const day = String(d.getDate()).padStart(2,'0');
		return `${y}-${m}-${day}`;
	}
	function formatDate(d){
		return d.toLocaleDateString('zh-TW',{ month:'2-digit', day:'2-digit'});
	}
	function getMonday(d){
		const x = new Date(d.getFullYear(), d.getMonth(), d.getDate());
		const day = x.getDay();
		const diff = (day===0? -6 : 1 - day); // to Monday
		return addDays(x,diff);
	}
	function addDays(d,days){
		const x = new Date(d.getFullYear(), d.getMonth(), d.getDate());
		x.setDate(x.getDate()+days);
		return x;
	}
	function fileToDataUrl(file){
		return new Promise((resolve,reject)=>{
			const reader = new FileReader();
			reader.onload = ()=> resolve(reader.result);
			reader.onerror = reject;
			reader.readAsDataURL(file);
		});
	}
	function openImage(src){
		const w = window.open();
		if(!w) return;
		w.document.write(`<img src="${src}" style="max-width:100%; height:auto; display:block; margin:0 auto;"/>`);
	}
	function cryptoRandomId(){
		if(window.crypto?.getRandomValues){
			const arr = new Uint32Array(4); window.crypto.getRandomValues(arr);
			return Array.from(arr).map(n=>n.toString(16).padStart(8,'0')).join('');
		}
		return `${Date.now().toString(16)}-${Math.random().toString(16).slice(2)}`;
	}
})();
